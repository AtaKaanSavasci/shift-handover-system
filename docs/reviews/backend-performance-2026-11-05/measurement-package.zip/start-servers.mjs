import {execFileSync} from 'node:child_process';
import fs from 'node:fs/promises';
const root='/workspace/shift-handover-system',out='/workspace/artifacts/backend-performance-2026-11-05',env={...process.env};
for(const key of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'])delete env[key];
const docker=(...args)=>execFileSync('docker',['--host=unix:///var/run/docker.sock',...args],{env,encoding:'utf8'}).trim();
if (!JSON.parse(docker('inspect','atak-backend-benchdb'))[0].NetworkSettings.Networks['atak-backend-network']) { docker('network','create','atak-backend-network'); docker('network','connect','atak-backend-network','atak-backend-benchdb'); }
for(const [name,dist,port] of [['baseline',out+'/baseline-dist',3100],['updated',root+'/dist',3101]]){
 await fs.mkdir(out+'/runtime-'+name,{recursive:true});
 const args=['run','-d','--rm','--name','atak-backend-'+name,'--network','atak-backend-network','--cpus','1','--memory','512m','-p',`127.0.0.1:${port}:3000`,'-w','/app'];
 for(const [src,dst]of [[dist,'/app/dist'],[root+'/node_modules','/app/node_modules'],[root+'/public','/app/public'],[root+'/package.json','/app/package.json'],[out+'/runtime.mjs','/app/runtime.mjs']])args.push('--mount',`type=bind,src=${src},dst=${dst},readonly`);
 args.push('--mount',`type=bind,src=${out}/runtime-${name},dst=/metrics`);
 for(const pair of ['DATABASE_URL=postgresql://ci:ci@atak-backend-benchdb:5432/'+(name==='updated'?'shift_perf_backend_updated':'shift_perf_backend'),'JWT_SECRET=backend-benchmark-disposable-jwt-secret-only','REGISTRATION_CODE=','AI_ENABLED=false','PERFORMANCE_LOGGING=true','NODE_ENV=production'])args.push('-e',pair);
 args.push('node:22-bookworm-slim','node','--import','./runtime.mjs','dist/index.js');docker(...args);
}
console.log('Isolated production containers started; benchmark will check readiness and warm both.');
