import {createRequire} from 'node:module';
import http from 'node:http';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
const root='/workspace/shift-handover-system',out='/workspace/artifacts/backend-performance-2026-11-05';
const require=createRequire(root+'/package.json'),jwt=require('jsonwebtoken'),{Client}=require('pg');
const secret='backend-benchmark-disposable-jwt-secret-only';
const fixture=JSON.parse(await fs.readFile(out+'/fixture.json','utf8'));
const variants=[{name:'baseline',base:'http://127.0.0.1:3100'},{name:'updated',base:'http://127.0.0.1:3101'}];
const tokens=Array.from({length:10},(_,i)=>jwt.sign({id:i+1},secret,{expiresIn:'2h'}));
const agent=new http.Agent({keepAlive:true,maxSockets:40});
const db=new Client({connectionString:'postgresql://ci:ci@127.0.0.1:55436/shift_perf_backend'});await db.connect();
const output={date:'2026-11-05',baseline:'b2e3b98 (observability on original 8c851c0 business code)',updatedCommit:'61d2f6b60b1d9cd1e762e3fa296c445c568e94fb',indexLayout:'Baseline database has the original eight migrations; updated database is cloned from it and then receives the open-board ordering index.',fixture:fixture.counts,conditions:{appCpu:1,appMemoryMiB:512,postgresCpu:0.5,postgresMemoryMiB:512,node:'22',transport:'loopback HTTP',logging:'PERFORMANCE_LOGGING=true in both variants',mix:['/operations/summary','/shifts/current','/operations/entries?view=open&page=1']},cases:[]};
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const quantile=(values,p)=>{values=[...values].sort((a,b)=>a-b);return values[Math.max(0,Math.ceil(values.length*p)-1)]??null};
function summarize(values){return {n:values.length,p50:quantile(values,.5),p95:quantile(values,.95),p99:quantile(values,.99),max:values.length?Math.max(...values):null}}
async function send(variant,path,index=0,method='GET',body=null,headers={}){
 const started=performance.now();return new Promise(resolve=>{
  let done=false,bytes=0,status=0;const chunks=[];
  const finish=error=>{if(done)return;done=true;clearTimeout(timer);resolve({path,status,error:error??null,ms:performance.now()-started,bytes,body:Buffer.concat(chunks).toString('utf8')});};
  const req=http.request(new URL(path,variant.base),{method,agent,headers:{Authorization:'Bearer '+tokens[index%10],...headers,...(body?{'Content-Length':body.length}:{})}},res=>{
   status=res.statusCode;res.on('data',chunk=>{bytes+=chunk.length;if(!path.startsWith('/shifts/export'))chunks.push(chunk);});res.on('end',()=>finish());res.on('error',e=>finish(e.code??e.message));
  });const timer=setTimeout(()=>req.destroy(new Error('15-second total deadline')),15000);req.on('error',e=>finish(e.code??e.message));if(body)req.write(body);req.end();
 });
}
async function fixed(variant,paths,n,concurrency=1){let next=0;const samples=[];await Promise.all(Array.from({length:concurrency},async()=>{while(next<n){const i=next++;samples.push(await send(variant,paths[i%paths.length],i));}}));return samples;}
async function closed(variant,concurrency,ms){let next=0;const samples=[],until=performance.now()+ms;await Promise.all(Array.from({length:concurrency},async()=>{while(performance.now()<until){const i=next++;samples.push(await send(variant,output.conditions.mix[i%3],i));}}));return samples;}
async function paced(variant){const start=performance.now(),jobs=[];for(let cycle=0;cycle<2;cycle++)for(let user=0;user<10;user++)jobs.push((async()=>{await delay(Math.max(0,start+cycle*30000+user*3000-performance.now()));return Promise.all(output.conditions.mix.map(path=>send(variant,path,user)));})());const rows=(await Promise.all(jobs)).flat();await delay(Math.max(0,start+60000-performance.now()));return rows;}
async function record(variant,name,work,metadata={}){
 await db.query('SELECT pg_stat_statements_reset()');const startedAt=new Date().toISOString(),start=performance.now();
 const raw=await work(),seconds=(performance.now()-start)/1000;const samples=raw.map(({body,...row})=>row),statuses={};for(const row of samples)statuses[row.status]=(statuses[row.status]??0)+1;
 const sql=(await db.query(`SELECT calls,total_exec_time,mean_exec_time,rows,query FROM pg_stat_statements WHERE query NOT ILIKE '%pg_stat_statements%' ORDER BY total_exec_time DESC LIMIT 10`)).rows;
 const entry={variant:variant.name,name,...metadata,startedAt,endedAt:new Date().toISOString(),seconds,completed:samples.length,statuses,transportErrors:samples.filter(r=>r.error).length,rps:samples.length/seconds,latencyMs:summarize(samples.map(r=>r.ms)),sql,samples};
 output.cases.push(entry);await fs.writeFile(out+'/api-comparison.json',JSON.stringify(output));console.log(JSON.stringify({variant:variant.name,name,...metadata,n:entry.completed,statuses,rps:+entry.rps.toFixed(2),p95:+entry.latencyMs.p95.toFixed(2)}));
 assert.equal(entry.transportErrors,0);if(!name.startsWith('concurrent-'))assert.ok(samples.every(r=>r.status===200));return entry;
}
try{
 for(const variant of variants){let ready=false;for(let i=0;i<80;i++){const r=await send(variant,'/app/');if(r.status===200&&!r.error){ready=true;break;}await delay(250);}assert.ok(ready,variant.name+' readiness');const warm=await fixed(variant,output.conditions.mix,30);assert.ok(warm.every(r=>r.status===200&&!r.error));}
 const before=await send(variants[0],'/operations/summary'),after=await send(variants[1],'/operations/summary');assert.deepEqual(JSON.parse(after.body),JSON.parse(before.body));console.log('Baseline and updated summary payloads match exactly on the seeded dataset.');
 for(let trial=1;trial<=3;trial++)for(const variant of trial%2?variants:[...variants].reverse())await record(variant,'summary',()=>fixed(variant,['/operations/summary'],50),{trial,concurrency:1});
 for(const concurrency of [1,10])for(let trial=1;trial<=3;trial++)for(const variant of trial%2?variants:[...variants].reverse())await record(variant,'read-mix',()=>closed(variant,concurrency,8000),{trial,concurrency,durationSeconds:8});
 for(const variant of [...variants].reverse())await record(variant,'paced-10-sessions',()=>paced(variant),{sessions:10,scheduledRps:1});
 const photo=await fs.readFile(out+'/synthetic-photo.jpg');
 for(const variant of variants){
  const form=new FormData();form.set('kind','TASK');form.set('title','Synthetic concurrent photo');form.set('description','Disposable benchmark record.');form.set('photos',new Blob([photo],{type:'image/jpeg'}),'synthetic.jpg');const response=new Response(form),body=Buffer.from(await response.arrayBuffer()),headers={'Content-Type':response.headers.get('content-type')};
  await record(variant,'concurrent-photos',()=>Promise.all(Array.from({length:3},(_,i)=>send(variant,'/operations/entries',i,'POST',body,headers))),{concurrency:3,inputPhotoBytes:photo.length});
  await record(variant,'concurrent-exports',()=>Promise.all(Array.from({length:3},()=>send(variant,'/shifts/export?scope=all',9))),{concurrency:3,rows:3010});
 }
}finally{agent.destroy();await db.end();}
