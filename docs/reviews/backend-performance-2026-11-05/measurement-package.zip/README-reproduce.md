# Backend performance comparison — November 5, 2026

This package contains synthetic local measurements and the scripts used to
reproduce them. It is not a production load-testing tool. The HTTP harness is
configured for two owned loopback servers and disposable PostgreSQL only.

- Original business code: `8c851c0` (after static asset caching).
- Instrumented baseline: `b2e3b98`, with the original six preview queries.
- Updated backend: `61d2f6b60b1d9cd1e762e3fa296c445c568e94fb`, with a batched preview statement, work limits and the open-board partial ordering index.
- Both apps: the same Node 22 image, production, 1 CPU / 512 MiB, query timing on.
- PostgreSQL 17: 0.5 CPU / 512 MiB, pg_stat_statements enabled.
- API generator and containers share the executor; all transport is loopback HTTP.

The scripts use `/workspace/shift-handover-system` as the checkout and
`/workspace/artifacts/backend-performance-2026-11-05` as the output directory.
Adjust these paths for another Linux/Docker environment. Unit/integration/browser
tests are separate from the measurements. Test databases and application secrets
in the harness are intentionally synthetic; never use them for a deployment.

Reproduction outline:

1. Build the baseline and updated commits with the same installed lockfile.
   Put the baseline compiled output in `baseline-dist/`; leave the updated build
   under the checkout's `dist/`. Prisma must be generated first. The final backend
   adds migration `20261105000100_open_board_order`.
2. Create a disposable PostgreSQL 17 service named `atak-backend-benchdb` at
   127.0.0.1:55436, database `shift_perf_backend`, synthetic user/password `ci`.
   Start PostgreSQL with `shared_preload_libraries=pg_stat_statements` and apply
   the original eight repository migrations to that database. Check readiness
   before migrations. Keep the new ordering index absent from this baseline DB.
3. Run `BENCH_RESET=1 node seed.mjs`. This explicitly truncates ONLY the named
   disposable database after checking its name and the reset flag. It writes
   `fixture.json` and the synthetic photo. Never point it at a real database.
4. With no app connected to the baseline DB, clone it to
   `shift_perf_backend_updated` and apply the new ordering-index migration only
   to that clone. Both datasets must have identical timestamps and IDs.
5. Run `node start-servers.mjs`. This mounts only dist/public/node_modules and
   package metadata, without the checkout's `.env`. Check for name/port conflicts
   before creating these task-specific containers/network.
6. Run `node api-comparison.mjs`. It checks readiness, warms both apps and verifies
   deep equality of summary JSON before timing. Avoid other CPU-intensive jobs.
7. Save `docker logs --timestamps` for each app and the `runtime-*/runtime.jsonl`
   files before deleting the temporary containers. `analyze.py` summarizes the
   output; raw samples remain in `api-comparison.json`.

The API cases alternate baseline/updated order across three trials, with 50
serial summary requests/trial and eight-second read-mix trials at concurrency 1
and 10. Normal polling has ten staggered sessions, three reads per session every
30 seconds, for 60 requests over 60 seconds per variant. The final cases issue
three simultaneous photo uploads and three simultaneous exports. HTTP 503 is the
expected overload response in the updated variant, not a transport failure.

An extra one-second runtime sampler was preloaded equally into both containers.
It observes CPU, RSS/heap and event-loop delay; short peaks may be missed. Prisma
query durations include driver/round-trip work and are distinct from PostgreSQL
execution times. This is not a physical-phone, public-hosting or cold-start test.

The `initial-union/` directory retains the first comparison before the index.
It regressed at concurrency 10 despite fewer round trips. `query-experiment.json`
and the plans show the scan that led to the index follow-up; the shared-ID CTE
was also measured but not selected. The final comparison uses separate cloned
databases so the baseline cannot benefit from the new index.
