import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
const env={...process.env};for(const name of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'])delete env[name];
const docker=(...args)=>execFileSync('docker',['--host=unix:///var/run/docker.sock',...args],{env,encoding:'utf8'}).trim();
const require=createRequire('/workspace/shift-handover-system/package.json'),{Client}=require('pg');
const db=new Client({connectionString:'postgresql://ci:ci@127.0.0.1:55436/shift_perf_backend_updated'});await db.connect();
try{
 const version=(await db.query('SHOW server_version')).rows[0].server_version;
 const index=(await db.query(`SELECT indexrelname,idx_scan,idx_tup_read FROM pg_stat_user_indexes WHERE indexrelname='OperationEntry_open_board_order'`)).rows[0];
 const output={node:docker('exec','atak-backend-updated','node','--version'),postgres:version,appImage:docker('inspect','--format','{{.Image}}','atak-backend-updated'),baselineImage:docker('inspect','--format','{{.Image}}','atak-backend-baseline'),appLimits:JSON.parse(docker('inspect','--format','{"nanoCpus":{{.HostConfig.NanoCpus}},"memoryBytes":{{.HostConfig.Memory}}}','atak-backend-updated')),postgresLimits:JSON.parse(docker('inspect','--format','{"nanoCpus":{{.HostConfig.NanoCpus}},"memoryBytes":{{.HostConfig.Memory}}}','atak-backend-benchdb')),parentCpuMax:(await fs.readFile('/sys/fs/cgroup/cpu.max','utf8')).trim(),parentMemoryMax:(await fs.readFile('/sys/fs/cgroup/memory.max','utf8')).trim(),index};
 await fs.writeFile('/workspace/artifacts/backend-performance-2026-11-05/environment.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify(output));
}finally{await db.end();}
