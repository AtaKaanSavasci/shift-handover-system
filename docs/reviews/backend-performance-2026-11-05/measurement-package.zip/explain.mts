import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import {summaryPanels} from '/workspace/shift-handover-system/src/services/summary-panels.ts';
const require=createRequire('/workspace/shift-handover-system/package.json'),{Client}=require('pg');
let captured:any;
await summaryPanels({$queryRaw:async (query:any)=>{captured=query;return[];}} as any);
const db=new Client({connectionString:'postgresql://ci:ci@127.0.0.1:55436/shift_perf_backend'});await db.connect();
try{const plan=await db.query('EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) '+captured.text,captured.values);await fs.writeFile('/workspace/artifacts/backend-performance-2026-11-05/union-plan.json',JSON.stringify(plan.rows[0]['QUERY PLAN'],null,2));
function walk(p:any,depth=0){console.log(' '.repeat(depth)+p['Node Type'],p['Relation Name']??'',p['Actual Total Time'],p['Actual Rows'],'loops',p['Actual Loops'],p['Workers Launched']??'');for(const child of p.Plans??[])walk(child,depth+1);}walk(plan.rows[0]['QUERY PLAN'][0].Plan);
console.log('Planning ms',plan.rows[0]['QUERY PLAN'][0]['Planning Time'],'execution ms',plan.rows[0]['QUERY PLAN'][0]['Execution Time']);}finally{await db.end();}
