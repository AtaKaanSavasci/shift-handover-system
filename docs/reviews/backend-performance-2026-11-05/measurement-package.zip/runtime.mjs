import {monitorEventLoopDelay} from 'node:perf_hooks';
import {appendFileSync} from 'node:fs';
const histogram=monitorEventLoopDelay({resolution:20});histogram.enable();let previous=process.cpuUsage(),wall=process.hrtime.bigint();
setInterval(()=>{const now=process.hrtime.bigint(),cpu=process.cpuUsage(),seconds=Number(now-wall)/1e9;appendFileSync('/metrics/runtime.jsonl',JSON.stringify({timestamp:new Date().toISOString(),rss:process.memoryUsage().rss,heapUsed:process.memoryUsage().heapUsed,cpuPercent:((cpu.user-previous.user+cpu.system-previous.system)/1e6)/seconds*100,eventLoopP95ms:histogram.percentile(95)/1e6,eventLoopMaxMs:histogram.max/1e6})+'\n');previous=cpu;wall=now;histogram.reset();},1000).unref();
