import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/workspace/artifacts/backend-performance-2026-11-05')
data=json.loads((root/'summary.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(12,4.2))
items=[('summary-1','medianTrialP95Ms','Summary p95','ms · lower is better'),('read-mix-10','medianTrialP95Ms','Read mix p95 · 10 concurrent','ms · lower is better'),('read-mix-10','medianTrialRps','Read mix throughput · 10 concurrent','requests/s · higher is better')]
for ax,(case,key,title,label) in zip(axes,items):
    values=[data['variants'][name][case][key] for name in ['baseline','updated']]
    bars=ax.bar(['Before','After'],values,color=['#94a3b8','#2563eb'],width=.55,zorder=3)
    ax.set_title(title,fontsize=11,pad=12);ax.set_ylabel(label,fontsize=9)
    ax.set_ylim(0,max(values)*1.24);ax.grid(axis='y',color='#e2e8f0',zorder=0)
    ax.spines[['top','right']].set_visible(False)
    for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,value+max(values)*.03,f'{value:.1f}',ha='center',fontweight='bold',fontsize=12)
fig.suptitle('Backend performance · local controlled A/B',fontsize=15,fontweight='bold',y=.98)
fig.text(.5,.03,'Median of 3 warm trials · app 1 CPU / 512 MiB · PostgreSQL 0.5 CPU / 512 MiB · loopback HTTP',ha='center',fontsize=9,color='#475569')
fig.subplots_adjust(top=.79,bottom=.22,wspace=.43)
fig.savefig(root/'comparison.svg',bbox_inches='tight');fig.savefig(root/'comparison.png',dpi=160,bbox_inches='tight');plt.close(fig)
