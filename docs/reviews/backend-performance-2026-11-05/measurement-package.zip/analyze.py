import json, statistics, datetime
from pathlib import Path
root=Path('/workspace/artifacts/backend-performance-2026-11-05')
data=json.loads((root/'api-comparison.json').read_text())
assert len(data['cases'])==24
assert all(row['transportErrors']==0 for row in data['cases'])
def median(values): return statistics.median(values)
def quantile(values,p):
    import math
    values=sorted(values)
    return values[max(0,math.ceil(len(values)*p)-1)] if values else None
def stamp(value): return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
summary={'date':data['date'],'baseline':data['baseline'],'updatedCommit':data['updatedCommit'],'conditions':data['conditions'],'fixture':data['fixture'],'variants':{},'scoredReadRequests':0}
for variant in ['baseline','updated']:
    cases=[row for row in data['cases'] if row['variant']==variant]
    reads=[row for row in cases if not row['name'].startswith('concurrent-')]
    assert all(set(row['statuses'])=={'200'} for row in reads)
    summary['scoredReadRequests']+=sum(row['completed'] for row in reads)
    result={}
    for name,concurrency in [('summary',1),('read-mix',1),('read-mix',10)]:
        rows=[row for row in reads if row['name']==name and row.get('concurrency')==concurrency]
        assert len(rows)==3
        result[name+'-'+str(concurrency)]={'trials':3,'requests':sum(row['completed'] for row in rows),'medianTrialRps':median([row['rps'] for row in rows]),'medianTrialP50Ms':median([row['latencyMs']['p50'] for row in rows]),'medianTrialP95Ms':median([row['latencyMs']['p95'] for row in rows]),'trialP95RangeMs':[min(row['latencyMs']['p95'] for row in rows),max(row['latencyMs']['p95'] for row in rows)]}
    paced=next(row for row in reads if row['name']=='paced-10-sessions')
    result['paced']={'requests':paced['completed'],'p50Ms':paced['latencyMs']['p50'],'p95Ms':paced['latencyMs']['p95']}
    for name in ['concurrent-photos','concurrent-exports']:
        row=next(row for row in cases if row['name']==name)
        result[name]={'statuses':row['statuses'],'transportErrors':row['transportErrors'],'maxMs':row['latencyMs']['max'],'samples':row['samples']}
    events=[]
    for line in (root/(variant+'.log')).read_text().splitlines():
        try:
            timestamp,content=line.split(' ',1); item=json.loads(content)
            if item.get('event')=='http_request': events.append((stamp(timestamp),item))
        except (ValueError,json.JSONDecodeError): pass
    for row in cases:
        selected=[item for time,item in events if stamp(row['startedAt'])<=time<=stamp(row['endedAt']) and item['completed']]
        row['observedMetrics']={'n':len(selected),'maxResponseRssBytes':max((item['rssBytes'] for item in selected),default=None),'maxPoolWaitingAtCompletion':max((item['pool']['waiting'] for item in selected if item['pool']),default=None)}
    summaries=[item for time,item in events if item['route']=='/operations/summary' and any(row['name']=='summary' and stamp(row['startedAt'])<=time<=stamp(row['endedAt']) for row in cases)]
    result['summaryMetrics']={'n':len(summaries),'medianQueries':median([item['database']['queries'] for item in summaries]),'medianDatabaseDurationMs':median([item['database']['durationMs'] for item in summaries])}
    summary['variants'][variant]=result
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'api-comparison-with-metrics.json').write_text(json.dumps(data))
print(json.dumps(summary,indent=2))
