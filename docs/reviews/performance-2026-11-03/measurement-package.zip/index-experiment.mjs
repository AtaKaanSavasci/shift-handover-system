import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import assert from 'node:assert/strict';

const require = createRequire('/workspace/shift-handover-system/package.json');
const { Client } = require('pg');
const connectionString = 'postgresql://ci:ci@127.0.0.1:55433/shift_perf';
const url = new URL(connectionString);
assert.equal(url.hostname, '127.0.0.1');
assert.equal(url.port, '55433');
assert.equal(url.pathname, '/shift_perf');
if (!process.argv.includes('--confirmed-idle-test-db')) {
  throw new Error('Run only after the parent confirms that the disposable DB is idle: --confirmed-idle-test-db');
}

const client = new Client({ connectionString, application_name: 'shift-perf-index-experiment' });
const indexes = [
  { name: 'perf_probe_operation_photo_entry_idx', sql: 'CREATE INDEX "perf_probe_operation_photo_entry_idx" ON "OperationPhoto" ("entryId")' },
  { name: 'perf_probe_shift_user_time_idx', sql: 'CREATE INDEX "perf_probe_shift_user_time_idx" ON "Shift" ("userId", "startTime", id)' }
];
const created = new Set();
const outputPath = '/workspace/artifacts/performance-2026-11-03/index-experiment.json';
const result = {
  sourceCommit: 'f123f6e',
  generatedAt: new Date().toISOString(),
  database: { host: url.hostname, port: Number(url.port), name: 'shift_perf' },
  methodology: {
    repetitions: 30,
    warmupsPerPhasePerQuery: 3,
    order: 'Photo and shift queries alternate within each repetition; their leading order alternates. Baseline phase precedes indexed phase.',
    sql: 'EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON); planner Execution Time excludes HTTP/auth/ORM overhead, and client wall time includes the local round trip.',
    parameters: 'Last20 OperationEntry IDs at the start of the experiment; fixed userId=1 for personal shift history.',
    caveats: [
      'Small synthetic fixture, warm shared buffers and OS cache; no cold-cache claims.',
      'Index creation itself warms pages, so before/after phases are not a fully randomized crossover.',
      'Only30 observations per query/phase: medians describe this run and are not a capacity or p95 production estimate.',
      'The direct SQL probes approximate two route/relation query shapes; they do not measure end-to-end API improvements.',
      'Indexes add write, storage and migration costs, which this experiment does not benchmark.',
      'SELECT of photo IDs does not read or transmit stored photo bytes.'
    ]
  },
  inventory: null,
  fixture: null,
  queries: {},
  phases: {},
  cleanup: { droppedIndexes: [] }
};

function percentile(values, fraction) {
  const sorted = [...values].sort((a, b) => a - b);
  if (!sorted.length) return null;
  const position = (sorted.length - 1) * fraction;
  const lower = Math.floor(position), upper = Math.ceil(position);
  return sorted[lower] + (sorted[upper] - sorted[lower]) * (position - lower);
}
function summary(rows) {
  return {
    count: rows.length,
    executionMedianMs: percentile(rows.map(x => x.executionMs), .5),
    planningMedianMs: percentile(rows.map(x => x.planningMs), .5),
    clientWallMedianMs: percentile(rows.map(x => x.clientWallMs), .5),
    executionMinMs: Math.min(...rows.map(x => x.executionMs)),
    executionMaxMs: Math.max(...rows.map(x => x.executionMs))
  };
}
async function explain(query, retain = true) {
  const start = performance.now();
  const response = await client.query('EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ' + query.sql, query.values);
  const clientWallMs = performance.now() - start;
  const plan = response.rows[0]['QUERY PLAN'][0];
  return {
    executionMs: plan['Execution Time'], planningMs: plan['Planning Time'], clientWallMs,
    ...(retain ? { plan } : {})
  };
}
async function phase(name, queries) {
  for (let i = 0; i < 3; i++) {
    const order = i % 2 ? [...queries].reverse() : queries;
    for (const [, query] of order) await explain(query, false);
  }
  const samples = Object.fromEntries(queries.map(([key]) => [key, []]));
  for (let i = 0; i < 30; i++) {
    const order = i % 2 ? [...queries].reverse() : queries;
    for (const [key, query] of order) samples[key].push({ repetition: i + 1, ...await explain(query) });
  }
  result.phases[name] = Object.fromEntries(Object.entries(samples).map(([key, rows]) => [key, { summary: summary(rows), samples: rows }]));
}

let failure;
try {
  await client.connect();
  const guard = await client.query('SELECT current_database() AS db');
  assert.equal(guard.rows[0].db, 'shift_perf', 'Refuse any other database.');
  await client.query("SET statement_timeout = '10s'");
  await client.query("SET lock_timeout = '2s'");
  const inventory = await client.query(`SELECT tablename, indexname, indexdef FROM pg_indexes
    WHERE schemaname='public' ORDER BY tablename, indexname`);
  result.inventory = inventory.rows;
  for (const index of indexes) {
    assert.ok(!inventory.rows.some(row => row.indexname === index.name), 'Probe index already exists: ' + index.name);
  }
  const fixture = await client.query(`SELECT (SELECT count(*)::int FROM "User") AS users,
    (SELECT count(*)::int FROM "Shift") AS shifts,
    (SELECT count(*)::int FROM "OperationEntry") AS entries,
    (SELECT count(*)::int FROM "OperationPhoto") AS photos,
    (SELECT count(*)::int FROM "OperationUpdate") AS notes`);
  result.fixture = fixture.rows[0];
  const ids = (await client.query('SELECT id FROM "OperationEntry" ORDER BY "createdAt" DESC, id DESC LIMIT 20')).rows.map(row => row.id);
  assert.ok(ids.length, 'Seed the disposable fixture first.');
  const matches = await client.query('SELECT count(*)::int AS count FROM "OperationPhoto" WHERE "entryId" = ANY($1::int[])', [ids]);
  result.fixture.selectedEntryIds = ids;
  result.fixture.matchingPhotos = matches.rows[0].count;
  result.fixture.user1Shifts = (await client.query('SELECT count(*)::int AS count FROM "Shift" WHERE "userId"=1')).rows[0].count;
  const queries = [
    ['photo_relation', { sql: 'SELECT id, "entryId" FROM "OperationPhoto" WHERE "entryId" = ANY($1::int[])', values: [ids] }],
    ['personal_shift_history', { sql: 'SELECT id, "userId", "startTime", "endTime", status, "shiftDate", "scheduledStart", "scheduledEnd" FROM "Shift" WHERE "userId"=$1 ORDER BY "startTime" DESC, id DESC LIMIT 20', values: [1] }]
  ];
  result.queries = Object.fromEntries(queries);
  await phase('before', queries);
  for (const index of indexes) {
    await client.query(index.sql);
    created.add(index.name);
  }
  await phase('after', queries);
} catch (error) {
  failure = error;
  result.error = { name: error.name, message: error.message };
} finally {
  for (const index of indexes) {
    if (!created.has(index.name)) continue;
    try {
      await client.query('DROP INDEX "' + index.name + '"');
      result.cleanup.droppedIndexes.push(index.name);
    } catch (error) {
      result.cleanup.error = { name: error.name, message: error.message };
      failure ||= error;
    }
  }
  if (created.size) {
    try {
      const remaining = await client.query('SELECT indexname FROM pg_indexes WHERE schemaname=$1 AND indexname = ANY($2::text[])', ['public', [...created]]);
      result.cleanup.remainingProbeIndexes = remaining.rows.map(row => row.indexname);
      assert.equal(result.cleanup.remainingProbeIndexes.length, 0, 'Probe indexes must be removed.');
    } catch (error) { result.cleanup.verificationError = error.message; failure ||= error; }
  }
  await client.end().catch(() => {});
  await writeFile(outputPath, JSON.stringify(result, null, 2));
}
if (failure) throw failure;
console.log(JSON.stringify({ outputPath, fixture: result.fixture,
  phases: Object.fromEntries(Object.entries(result.phases).map(([name, phase]) => [name,
    Object.fromEntries(Object.entries(phase).map(([key, data]) => [key, data.summary]))])), cleanup: result.cleanup }, null, 2));
