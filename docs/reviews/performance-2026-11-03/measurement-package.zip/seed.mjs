import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import {scryptSync,randomBytes} from 'node:crypto';
const root='/workspace/shift-handover-system', out='/workspace/artifacts/performance-2026-11-03';
const require=createRequire(root+'/package.json'), {Client}=require('pg'), sharp=require('sharp');
const connectionString='postgresql://ci:ci@127.0.0.1:55433/shift_perf';
const db=new Client({connectionString});await db.connect();
try {
 const name=(await db.query('select current_database() as name')).rows[0].name;if(name!=='shift_perf'||process.env.BENCH_RESET!=='1')throw Error('Only the explicitly authorized disposable shift_perf database may be reset.');
 await db.query('CREATE EXTENSION IF NOT EXISTS pg_stat_statements');
 await db.query('TRUNCATE "User", "OperationEntry", "EquipmentChange", "HandoverRead", "Shift" RESTART IDENTITY CASCADE');
 await db.query(`INSERT INTO "Equipment"(code,name) VALUES ('GT1','Gas turbine 1'),('GT2','Gas turbine 2'),('ST','Steam turbine') ON CONFLICT DO NOTHING`);
 const password='performance-test-password-only',salt=randomBytes(16).toString('hex'),hash=salt+':'+scryptSync(password,salt,64).toString('hex');
 for(let i=1;i<=10;i++)await db.query('INSERT INTO "User"(email,name,password,role) VALUES($1,$2,$3,$4::"Role")',['operator'+i+'@benchmark.invalid','Sentetik Operatör '+i,hash,i===10?'MANAGER':'WORKER']);
 await db.query(`INSERT INTO "Shift"("userId",status,"startTime","endTime","shiftDate","scheduledStart","scheduledEnd") SELECT ((i-1)%10)+1,'COMPLETED',now()-(i*interval '8 hours'),now()-(i*interval '8 hours')+interval '8 hours',to_char(now()-(i*interval '8 hours'),'YYYY-MM-DD'),'08:00','16:00' FROM generate_series(1,3000) i`);
 await db.query(`INSERT INTO "Shift"("userId",status,"startTime","shiftDate","scheduledStart","scheduledEnd") SELECT i,'ACTIVE',now()-interval '1 hour',to_char(now(),'YYYY-MM-DD'),'08:00','16:00' FROM generate_series(1,10) i`);
 await db.query(`INSERT INTO "OperationEntry"(kind,priority,title,description,"authorId","shiftId","equipmentCode","createdAt","closedAt","closedById","closeNote","workStatus","responsibleTeam","nextStep")
 SELECT (ARRAY['TASK','VALVE','ATTENTION','EVENT','NOTE'])[((i-1)%5)+1]::"EntryKind",CASE WHEN i%7=0 THEN 'HIGH' ELSE 'NORMAL' END::"EntryPriority",(ARRAY['GT1','GT2','ST'])[((i-1)%3)+1]||' sentetik kontrol '||i,'Sentetik vardiya kaydı. Basınç ve titreşim gözlemi; bakım ekibinin sonucu ve sonraki adımı kontrol etmesi bekleniyor. Kayıt numarası '||i,((i-1)%10)+1,CASE WHEN i>9900 THEN 3000+((i-1)%10)+1 ELSE ((i-1)%3000)+1 END,(ARRAY['GT1','GT2','ST'])[((i-1)%3)+1],now()-((10000-i)*interval '30 minutes'),CASE WHEN i<=9800 AND i%5 IN (1,2,3) THEN now()-((10000-i)*interval '30 minutes')+interval '15 minutes' ELSE null END,CASE WHEN i<=9800 AND i%5 IN (1,2,3) THEN ((i-1)%10)+1 ELSE null END,CASE WHEN i<=9800 AND i%5 IN (1,2,3) THEN 'Kontrol tamamlandı.' ELSE null END,(ARRAY['OPEN','IN_PROGRESS','WAITING'])[((i-1)%3)+1]::"WorkStatus",CASE WHEN i%2=0 THEN 'Mekanik' ELSE 'Elektrik' END,'Sonraki vardiyada sonucu doğrula.' FROM generate_series(1,10000) i`);
 await db.query(`INSERT INTO "OperationUpdate"("entryId","authorId",body,"requestId","createdAt") SELECT ((i-1)%300)+9701,((i-1)%10)+1,'Sentetik gelişme notu '||i,gen_random_uuid(),now()-(i*interval '3 minutes') FROM generate_series(1,3000) i`);
 await db.query(`INSERT INTO "WorkDetailChange"("entryId","authorId",version,"workStatus","responsibleTeam","nextStep","createdAt") SELECT 9700+i,((i-1)%10)+1,1,'IN_PROGRESS','Mekanik','Sentetik inceleme sürüyor.',now()-(i*interval '5 minutes') FROM generate_series(1,300) i`);
 const width=1600,height=1200,pixels=Buffer.alloc(width*height*3);for(let y=0;y<height;y++)for(let x=0;x<width;x++){const n=(y*width+x)*3,d=(x*17+y*13)%29;pixels[n]=Math.min(255,40+x/14+d);pixels[n+1]=Math.min(255,60+y/12+d);pixels[n+2]=Math.min(255,90+(x+y)/22+d);}
 const photo=await sharp(pixels,{raw:{width,height,channels:3}}).jpeg({quality:80}).toBuffer();await fs.writeFile(out+'/synthetic-photo.jpg',photo);
 await db.query(`INSERT INTO "OperationPhoto"(id,"entryId",data) SELECT gen_random_uuid()::text,10000-((i-1)*17),$1::bytea FROM generate_series(1,500) i`,[photo]);
 await db.query(`UPDATE "Equipment" SET status='ACTIVE',note='Sentetik performans test verisi',"updatedAt"=now(),"updatedById"=1`);
 await db.query(`UPDATE "OperationRevision" SET version=100`);
 await db.query('ANALYZE');
 const counts=(await db.query(`SELECT (SELECT count(*)::int FROM "User") users,(SELECT count(*)::int FROM "Shift") shifts,(SELECT count(*)::int FROM "OperationEntry") entries,(SELECT count(*)::int FROM "OperationEntry" WHERE "closedAt" IS NULL AND kind IN ('TASK','VALVE','ATTENTION')) open_items,(SELECT count(*)::int FROM "OperationPhoto") photos,(SELECT count(*)::int FROM "OperationUpdate") updates,(SELECT count(*)::int FROM "WorkDetailChange") work_changes,pg_database_size(current_database())::text database_bytes`)).rows[0];
 const photoId=(await db.query('select id from "OperationPhoto" order by "createdAt" desc limit 1')).rows[0].id;
 await fs.writeFile(out+'/fixture.json',JSON.stringify({seededAt:new Date().toISOString(),counts,photoBytes:photo.length,photoId,workerEmail:'operator1@benchmark.invalid',managerEmail:'operator10@benchmark.invalid',password,workerId:1,managerId:10},null,2));
 console.log(JSON.stringify({counts,photoBytes:photo.length}));
}finally{await db.end();}
