import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='/workspace/shift-handover-system',out='/workspace/artifacts/performance-2026-11-03';const require=createRequire(root+'/package.json');const {chromium}=require('@playwright/test');
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],network=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url())});
 await page.setContent(await fs.readFile(out+'/performans-raporu.html','utf8'));await page.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth>0));
 assert.equal(await page.locator('main>section').count(),9);assert.equal(await page.locator('figure img').count(),3);
 const expected=JSON.parse(await fs.readFile(out+'/report-data.json','utf8'));assert.deepEqual(JSON.parse(await page.locator('#report-data').textContent()),expected);
 const pending=page.waitForEvent('download');await page.locator('#download-data').click();const download=await pending;await download.saveAs(out+'/download-check.json');assert.deepEqual(JSON.parse(await fs.readFile(out+'/download-check.json','utf8')),expected);
 for(const width of [390,320]){await page.setViewportSize({width,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'Horizontal overflow at'+width);}
 await page.setViewportSize({width:1440,height:1000});await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:out+'/report-preview.png'});
 await page.pdf({path:out+'/performans-raporu.pdf',format:'A4',printBackground:true,preferCSSPageSize:true,displayHeaderFooter:true,headerTemplate:'<div></div>',footerTemplate:'<div style="font-size:8px;width:100%;padding:0 13mm;color:#63718a;display:flex;justify-content:space-between"><span>Vardiya Defteri ·3 Kasım2026 ·f123f6e</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>'});
 assert.deepEqual(errors,[]);assert.deepEqual(network,[]);console.log('PASS:9 sections,3 charts,data download,320/390px layouts,zero JS errors/external requests;PDF generated.');
}finally{await browser.close();}
