# Shift Handover performance experiment — 2026-11-03

This package is a dated experiment, not a production load-testing service. The
Turkish report is `performans-raporu.pdf` (9 pages) or the self-contained
`performans-raporu.html`. `report-data.json` holds selected results; full samples
are in `api-1cpu.json`, `api-0.1cpu.json` and `browser-results.json`.

## Conditions

Source: f123f6e47125816d4ca871b4075a2ba9435ede9e. Production build, Node22.23.4,
PostgreSQL17.11. App limits:1CPU or0.1CPU,512MiB. Database:0.5CPU,512MiB.
The shared host was limited to2CPU/8GiB. Load generator used host Node24.19.
See `environment.json` for exact image digests and caveats. This is loopback HTTP,
not an internet/TLS/Render/Neon benchmark. No real AI calls or real operational
records were used. Application files were not changed.

## Harness and safe scope

The scripts record this Linux/Docker workspace: project root
`/workspace/shift-handover-system`, artifact root
`/workspace/artifacts/performance-2026-11-03`. Adjust those constants if placing
the package elsewhere. They use the project's installed `pg`, `jsonwebtoken`,
`sharp` and `@playwright/test`; no extra runtime package is required.

- `seed.mjs`: synthetic fixture reset; requires `BENCH_RESET=1` and only connects
  to the dedicated `127.0.0.1:55433/shift_perf` database.
- `api-benchmark.mjs`: refuses non-loopback HTTP targets. Keeps authentication and
  rate limits. Waits for readiness and30 successful warm-up requests before
  scoring. Runs60 seconds of paced polling, route samples,3×12-second read sweeps
  and bounded login/write/photo/export samples.
- `browser-benchmark.mjs`:5 desktop +5 emulated-mobile trials against the warm
  1CPU backend. Do not run concurrently with the API sweep.
- `measure-runtime.mjs`: app-process RSS/CPU/event-loop samples once per second.
- `index-experiment.mjs`: requires `--confirmed-idle-test-db`. Creates and drops
  only two uniquely named probe indexes on the disposable database. Run while
  the load generators are stopped.
- `summarize.py`, `build-report.py`, `render-verify.mjs`: data aggregation, charts,
  HTML and PDF verification. Chart generation additionally uses Python
  matplotlib/numpy; PDF is generated with installed Playwright/system Chromium.

## Setup notes

Use an isolated test checkout at the recorded commit. Do not load its real `.env`.
The original run set `DOTENV_CONFIG_PATH=/dev/null` for build/migration commands.
All database passwords and signing values below are test-only fixtures.

```sh
npm ci
DOTENV_CONFIG_PATH=/dev/null DATABASE_URL=postgresql://ci:ci@127.0.0.1:55433/shift_perf npm run build

docker network create atak-perf-network
docker run -d --name atak-perf-postgres --network atak-perf-network \
  -p 127.0.0.1:55433:5432 --cpus 0.5 --memory 512m \
  -e POSTGRES_USER=ci -e POSTGRES_PASSWORD=ci -e POSTGRES_DB=shift_perf \
  postgres:17 -c shared_preload_libraries=pg_stat_statements -c track_io_timing=on
# Wait for pg_isready before migrations.
DOTENV_CONFIG_PATH=/dev/null DATABASE_URL=postgresql://ci:ci@127.0.0.1:55433/shift_perf npx prisma migrate deploy
BENCH_RESET=1 node /workspace/artifacts/performance-2026-11-03/seed.mjs
mkdir -p /workspace/artifacts/performance-2026-11-03/metrics
```

Start Node using read-only mounts of **only** dist, public, node_modules and
package.json; the root `.env` is not mounted. Mount the runtime sampler and its
output folder separately. The recorded command was:

```sh
docker run -d --name atak-perf-app --network atak-perf-network \
  -p 127.0.0.1:3100:3000 --cpus 1 --memory 512m --workdir /app \
  --mount type=bind,src=/workspace/shift-handover-system/dist,dst=/app/dist,readonly \
  --mount type=bind,src=/workspace/shift-handover-system/public,dst=/app/public,readonly \
  --mount type=bind,src=/workspace/shift-handover-system/node_modules,dst=/app/node_modules,readonly \
  --mount type=bind,src=/workspace/shift-handover-system/package.json,dst=/app/package.json,readonly \
  --mount type=bind,src=/workspace/artifacts/performance-2026-11-03/measure-runtime.mjs,dst=/bench/measure-runtime.mjs,readonly \
  --mount type=bind,src=/workspace/artifacts/performance-2026-11-03/metrics,dst=/metrics \
  -e DATABASE_URL=postgresql://ci:ci@atak-perf-postgres:5432/shift_perf \
  -e JWT_SECRET=performance-only-disposable-jwt-secret-2026 \
  -e REGISTRATION_CODE= -e AI_ENABLED=false -e NODE_ENV=production \
  node:22-bookworm-slim node --import /bench/measure-runtime.mjs dist/index.js
```

The managed environment used the explicit local Docker socket while preserving
proxy/CA settings. On an ordinary Docker setup the commands above use your local
Docker context. Use the pinned digests in `environment.json` for exact images.

## Measurement order

1. Wait for `/app/` HTTP200. Run browser-only measurements with
   `BENCH_EMAIL=operator1@benchmark.invalid` and
   `BENCH_PASSWORD=performance-test-password-only` (synthetic credentials).
2. Run `BENCH_PROFILE=1cpu node .../api-benchmark.mjs` with no browser traffic.
3. During an idle window run `node .../index-experiment.mjs --confirmed-idle-test-db`.
4. Reset/reseed the same logical fixture; set `docker update --cpus 0.1
   atak-perf-app`, restart it, wait for readiness and run `BENCH_PROFILE=0.1cpu`.
5. Restore/clean up only these test resources after measurement:

```sh
docker rm -f -v atak-perf-app atak-perf-postgres
docker network rm atak-perf-network
```

The updated harness includes the readiness and export-window fixes discovered
while preparing this measurement. Exact numerical results will vary with host
scheduling, versions, query caches and workload ordering.

## Recorded corrections

The initial0.1CPU paced window started before the container was ready, producing
12 immediate ECONNRESETs and48 successes. `api-0.1cpu-initial.json` preserves it.
It was repeated after HTTP readiness,30 successful warmups and a fresh fixture;
the final60 requests all succeeded. `api-0.1cpu-paced.json` contains that retest.

The first1CPU export wrapper timed the wrong surrounding window. Three exports
were repeated inside the measured window in a fresh1CPU process;
`api-1cpu-export.json` supersedes only that case. Other original observations are
unchanged. Corrections are explicit in the scored API JSON and `report-data.json`.
Initial observations are retained for audit and are not scored warm failures.

## Interpretation

22,774 scored warm requests were all2xx without a transport error. This does not
mean the whole app is bug-free. Stress p95 values are the median of three trial
p95s; they are not a pooled percentile. Small fixed samples are descriptive.
Browser values are medians of five trials, not Lighthouse/INP/field CWV. Gzip
savings use Python gzip level9 with mtime=0; they are a byte calculation, not a deployed speedup. The index probes improve
SQL plans but do not demonstrate a material end-to-end improvement.
