import {createRequire} from 'node:module';
import http from 'node:http';
import fs from 'node:fs/promises';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
const root='/workspace/shift-handover-system',out='/workspace/artifacts/performance-2026-11-03';
const require=createRequire(root+'/package.json'),jwt=require('jsonwebtoken'),{Client}=require('pg');
const base=new URL(process.env.BENCH_BASE_URL||'http://127.0.0.1:3100');
if(!['127.0.0.1','localhost'].includes(base.hostname))throw Error('This harness is restricted to the isolated loopback fixture, never a public target.');
const fixture=JSON.parse(await fs.readFile(out+'/fixture.json','utf8')),secret='performance-only-disposable-jwt-secret-2026';
const profile=process.env.BENCH_PROFILE||'1cpu',repeat=3,duration=12000;
const resultFile=out+'/api-'+profile+(process.env.BENCH_ONLY?'-'+process.env.BENCH_ONLY:'')+'.json';
const tokens=Array.from({length:10},(_,i)=>jwt.sign({id:i+1},secret,{algorithm:'HS256',expiresIn:'2h'}));
const db=new Client({connectionString:'postgresql://ci:ci@127.0.0.1:55433/shift_perf'});await db.connect();
const results={profile,startedAt:new Date().toISOString(),base:base.origin,fixture:fixture.counts,definitions:{latency:'Client request dispatch until complete response body; keep-alive, no pipelining, includes queue and network on loopback.',throughput:'Completed requests divided by measured wall time including draining outstanding requests.',concurrency:'Maximum concurrent HTTP requests in a closed loop, not simultaneous human users.',percentile:'Nearest-rank per trial, includes all statuses; successful response quantiles are also reported.',paced:'10 sessions staggered every 3s, each polls 3 GET concurrently once per30s,60s total,60 requests; arrival schedule is independent of completions.',limits:'Original application rate limits remain active. Writes/export/login intentionally bounded. No real AI call.'},cases:[]};
let agent=new http.Agent({keepAlive:true,maxSockets:100});
const quantile=(values,p)=>values.length?[...values].sort((a,b)=>a-b)[Math.max(0,Math.ceil(values.length*p)-1)]:null;
const summary=values=>({n:values.length,p50:quantile(values,.5),p95:quantile(values,.95),p99:quantile(values,.99),max:values.length?Math.max(...values):null});
async function request(path,tokenIndex=0,method='GET',body=null,headers={}) {
 const started=performance.now();
 return new Promise(resolve=>{
  let done=false,ttfb=null,bytes=0;const end=(status,error=null)=>{if(done)return;done=true;clearTimeout(deadline);resolve({path,method,status,error,ms:performance.now()-started,ttfb,bytes});};
  const req=http.request(new URL(path,base),{agent,method,headers:{Authorization:'Bearer '+tokens[tokenIndex],...headers,...(body?{'Content-Length':body.length}:{})}},res=>{
   ttfb=performance.now()-started;res.on('data',b=>{bytes+=b.length});res.on('end',()=>end(res.statusCode));res.on('error',e=>end(res.statusCode,e.code||e.message));
  });
  const deadline=setTimeout(()=>req.destroy(new Error('total request deadline 15s')),15000);
  req.on('error',e=>end(0,e.code||e.message));if(body)req.write(body);req.end();
 });
}
const mix=['/operations/summary','/shifts/current','/operations/entries?view=open&page=1'];
async function record(name,work,metadata={}){
 const startAt=new Date().toISOString();await db.query('select pg_stat_statements_reset()');
 const start=performance.now(),cpu=process.cpuUsage(),loop=monitorEventLoopDelay({resolution:20});loop.enable();
 const samples=await work(),seconds=(performance.now()-start)/1000,cpuUsed=process.cpuUsage(cpu);loop.disable();
 const statuses={};for(const s of samples)statuses[s.status]=(statuses[s.status]||0)+1;
 const sql=(await db.query(`SELECT calls,total_exec_time,mean_exec_time,rows,query FROM pg_stat_statements WHERE query NOT ILIKE '%pg_stat_statements%' ORDER BY total_exec_time DESC LIMIT 6`)).rows;
 const entry={name,profile,...metadata,startAt,endAt:new Date().toISOString(),seconds,completed:samples.length,successful:samples.filter(s=>s.status>=200&&s.status<300&&!s.error).length,statuses,transportErrors:samples.filter(s=>s.error).length,rps:samples.length/seconds,successRps:samples.filter(s=>s.status>=200&&s.status<300&&!s.error).length/seconds,latencyMs:summary(samples.map(s=>s.ms)),successLatencyMs:summary(samples.filter(s=>s.status>=200&&s.status<300&&!s.error).map(s=>s.ms)),ttfbMs:summary(samples.map(s=>s.ttfb).filter(s=>s!==null)),clientCpuMs:(cpuUsed.user+cpuUsed.system)/1000,clientEventLoopP95ms:loop.percentile(95)/1e6,bytes:samples.reduce((n,s)=>n+s.bytes,0),topSql:sql,samples};
 results.cases.push(entry);await fs.writeFile(resultFile,JSON.stringify(results));console.log(JSON.stringify({name,...metadata,completed:entry.completed,statuses,rps:+entry.rps.toFixed(2),p95:+entry.latencyMs.p95.toFixed(2)}));
}
async function fixed(paths,count,concurrency=1,method='GET',factory=null){
 let assigned=0;const samples=[];
 await Promise.all(Array.from({length:concurrency},async()=>{while(assigned<count){const i=assigned++;const payload=factory?await factory(i):{};samples.push(await request(paths[i%paths.length],i%10,method,payload.body||null,payload.headers||{}));}}));return samples;
}
async function closed(concurrency){let i=0;const samples=[],until=performance.now()+duration;await Promise.all(Array.from({length:concurrency},async()=>{while(performance.now()<until){const n=i++;samples.push(await request(mix[n%3],n%10));}}));return samples;}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const paced=async()=>{const start=performance.now(),tasks=[];for(let cycle=0;cycle<2;cycle++)for(let user=0;user<10;user++)tasks.push((async()=>{const due=start+cycle*30000+user*3000;await sleep(Math.max(0,due-performance.now()));const late=performance.now()-due;const data=await Promise.all(mix.map(path=>request(path,user)));return data.map(s=>({...s,scheduledDelayMs:late}));})());const all=(await Promise.all(tasks)).flat();await sleep(Math.max(0,start+60000-performance.now()));return all;};
async function readyAndWarm(){let ready=false;for(let i=0;i<90;i++){const r=await request('/app/');if(r.status===200&&!r.error){ready=true;break;}await sleep(500);}if(!ready)throw Error('Server never became ready');const warm=await fixed(mix,30,1);if(warm.some(r=>r.status!==200||r.error))throw Error('Warm-up requests must succeed before timing');}
try {
 if(process.env.BENCH_ONLY==='paced'){
 await readyAndWarm();await record('paced-10-sessions',paced,{sessions:10,scheduledRps:1});
 }else if(process.env.BENCH_ONLY==='export'){
 await record('export-3010-shifts',async()=>{const rows=[];for(let i=0;i<3;i++)rows.push(await request('/shifts/export?scope=all',9));return rows;},{concurrency:1});
 }else{
 // Prime connection pools, query caches and representative payloads before timing.
 await readyAndWarm();
 await record('paced-10-sessions',paced,{sessions:10,scheduledRps:1});
 const routeCases=[['summary','/operations/summary'],['open-board','/operations/entries?view=open&page=1'],['history','/operations/entries?view=history&page=1'],['search','/operations/entries?view=all&q=titre%C5%9Fim&page=1'],['shift-history','/shifts?page=1'],['photo','/operations/photos/'+fixture.photoId]];
 for(const [name,path]of routeCases)await record(name,()=>fixed([path],profile==='1cpu'?30:15,1),{concurrency:1});
 const levels=profile==='1cpu'?[1,10,30,50]:[1,10];
 for(const concurrency of levels)for(let trial=1;trial<=repeat;trial++)await record('handover-read-mix',()=>closed(concurrency),{concurrency,trial,durationSeconds:duration/1000});
 await record('login',()=>fixed(['/login'],6,1,'POST',()=>({body:Buffer.from(JSON.stringify({email:fixture.workerEmail,password:fixture.password})),headers:{'Content-Type':'application/json'}})),{concurrency:1});
 await record('create-text',()=>fixed(['/operations/entries'],24,4,'POST',i=>({body:Buffer.from(JSON.stringify({kind:'TASK',priority:'NORMAL',title:'Sentetik perf '+profile+' '+i,description:'Yalnızca geçici performans verisi',equipmentCode:'GT1'})),headers:{'Content-Type':'application/json'}})),{concurrency:4});
 const photo=await fs.readFile(out+'/synthetic-photo.jpg');
 await record('create-photo',()=>fixed(['/operations/entries'],8,2,'POST',async i=>{const data=new FormData();data.set('kind','TASK');data.set('title','Sentetik photo '+profile+' '+i);data.set('description','Geçici fotoğraf performans deneyi');data.set('photos',new Blob([photo],{type:'image/jpeg'}),'synthetic.jpg');const response=new Response(data);return {body:Buffer.from(await response.arrayBuffer()),headers:{'Content-Type':response.headers.get('content-type')}};}),{concurrency:2,inputPhotoBytes:photo.length});
 // Use the manager's genuine database role for an all-team export. Three calls remain below5/IP/15min.
 await record('export-3010-shifts',async()=>{const rows=[];for(let i=0;i<3;i++)rows.push(await request('/shifts/export?scope=all',9));return rows;},{concurrency:1});
}
}finally{agent.destroy();await db.end();}
