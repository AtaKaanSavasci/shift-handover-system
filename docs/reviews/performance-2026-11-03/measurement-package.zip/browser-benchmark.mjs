import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { performance as clock } from 'node:perf_hooks';
import { resolve } from 'node:path';

const root='/workspace/shift-handover-system';
const require=createRequire(root+'/package.json');
const { chromium }=require('@playwright/test');
const base=process.env.BENCH_BASE_URL || 'http://127.0.0.1:3100';
const email=process.env.BENCH_EMAIL, password=process.env.BENCH_PASSWORD;
if(!email || !password)throw new Error('Set BENCH_EMAIL and BENCH_PASSWORD to disposable synthetic test credentials.');
const output=resolve(process.env.BENCH_OUTPUT_DIR || '/workspace/artifacts/performance-2026-11-03');
const n=Number(process.env.BENCH_TRIALS || 5);
if(!Number.isInteger(n)||n<1||n>10)throw new Error('BENCH_TRIALS must be 1–10; remember the unchanged 20 login requests/15min/IP limit.');
await mkdir(output,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});
const result={
 measuredAt:new Date().toISOString(),baseUrl:base,browser:browser.version(),node:process.version,
 trialCountPerProfile:n,
 definitions:{
  authReadyMs:'Navigation-start to visible and enabled login form, observed after page load. Fresh browser context per trial; server and database already running.',
  reloadAuthReadyMs:'Same browser context reload to visible login form; tests actual HTTP caching behavior, not an assumed cache hit.',
  loginOverviewReadyMs:'Login click capture event to completed login/current/summary/AI-status responses, three equipment cards, enabled refresh control and two animation frames.',
  pageReadyMs:'Navigation click capture event to target page visible, required GET responses complete, relevant busy controls settled and two animation frames. Includes backend/network/render work; this is not INP.',
  themeToggleMs:'Theme switch click capture event to changed root data-theme and two animation frames.',
  resources:'Resource Timing byte counts from the browser; encodedBodySize is transmitted body, transferSize includes headers. Does not include subsequent API polling.',
  longTasks:'Browser PerformanceObserver long-task entries since the same-context reload; first-load entries are stored separately. Not a Lighthouse score or field Core Web Vitals.'
 },
 caveats:['Local loopback server/database; no Render/Neon region, TLS, sleep or cold-start measurement.','Mobile profile is Chromium emulation, not a physical Android phone.','Five trials by default: median/range are descriptive; no reliable population p95 inferred.','No AI model call, photo upload, write or export in browser timings.','No parallel API load during this browser phase; existing app rate limits unchanged.'],
 profiles:[]
};
const pathname=response=>new URL(response.url()).pathname;
function responseWait(page,path){return page.waitForResponse(r=>r.request().method()==='GET'&&pathname(r)===path,{timeout:30000});}
async function frameSettled(page){await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));}
async function startClick(page,selector){
 await page.locator(selector).evaluate(el=>el.addEventListener('click',()=>{window.__benchClick=performance.now();},{capture:true,once:true}));
 await page.locator(selector).click();
}
async function clickElapsed(page){return page.evaluate(()=>performance.now()-window.__benchClick);}
async function navigationSnapshot(page){return page.evaluate(()=>{
 const nav=performance.getEntriesByType('navigation')[0];
 return {navigation:nav?{responseStart:nav.responseStart,responseEnd:nav.responseEnd,domContentLoaded:nav.domContentLoadedEventEnd,loadEventEnd:nav.loadEventEnd,transferSize:nav.transferSize,encodedBodySize:nav.encodedBodySize,decodedBodySize:nav.decodedBodySize}:null,
 paints:performance.getEntriesByType('paint').map(e=>({name:e.name,startTime:e.startTime})),
 resources:performance.getEntriesByType('resource').filter(e=>new URL(e.name).pathname.startsWith('/app/')).map(e=>({path:new URL(e.name).pathname,duration:e.duration,transferSize:e.transferSize,encodedBodySize:e.encodedBodySize,decodedBodySize:e.decodedBodySize,initiatorType:e.initiatorType}))};
 });}
async function authReady(page){
 await page.locator('#auth-view').waitFor({state:'visible'});
 await page.waitForFunction(()=>{const b=document.getElementById('login-button');return b&&!b.disabled&&document.getElementById('email')&&document.getElementById('password');});
 await frameSettled(page);
 return page.evaluate(()=>performance.now());
}
async function navigate(page,pageName){
 const endpoints=pageName==='handover'?['/operations/summary','/operations/entries','/shifts/current']:pageName==='history'?['/operations/entries','/shifts']:pageName==='overview'?['/operations/summary','/shifts/current']:[];
 const pending=endpoints.map(path=>responseWait(page,path));
 await startClick(page,`[data-nav="${pageName}"]`);
 await page.locator(`#page-${pageName}`).waitFor({state:'visible'});
 const responses=await Promise.all(pending);
 await Promise.all(responses.map(r=>r.finished()));
 for(const r of responses)if(r.status()!==200)throw new Error(`Unexpected HTTP ${r.status()} for ${new URL(r.url()).pathname}`);
 if(pageName==='handover')await page.waitForFunction(()=>document.getElementById('board-entries').getAttribute('aria-busy')==='false');
 if(pageName==='history')await page.waitForFunction(()=>document.getElementById('table-loading').hidden&&!document.querySelector('#operations-filter button[type="submit"]').disabled);
 if(pageName==='overview')await page.waitForFunction(()=>!document.getElementById('overview-refresh').disabled);
 await frameSettled(page);
 return {page:pageName,durationMs:await clickElapsed(page),requiredRequests:endpoints.length,overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)};
}
function stats(values){const sorted=[...values].sort((a,b)=>a-b);return {n:values.length,min:sorted[0],median:sorted.length%2?sorted[(sorted.length-1)/2]:(sorted[sorted.length/2-1]+sorted[sorted.length/2])/2,max:sorted.at(-1)};}
try{
 for(const profile of [
  {name:'desktop_local',viewport:{width:1440,height:1000},deviceScaleFactor:1,isMobile:false,hasTouch:false,cpu:1,network:null},
  {name:'mobile_emulated_4x_cpu_150ms_1_6mbps',viewport:{width:390,height:844},deviceScaleFactor:1,isMobile:true,hasTouch:true,cpu:4,network:{offline:false,latency:150,downloadThroughput:1_600_000/8,uploadThroughput:750_000/8,connectionType:'cellular4g'}}
 ]){
  const collected={name:profile.name,conditions:profile,trials:[]};
  for(let trial=1;trial<=n;trial++){
   const context=await browser.newContext({viewport:profile.viewport,deviceScaleFactor:profile.deviceScaleFactor,isMobile:profile.isMobile,hasTouch:profile.hasTouch,reducedMotion:'reduce',locale:'tr-TR'});
   const page=await context.newPage();page.setDefaultTimeout(30000);
   const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');
   await cdp.send('Emulation.setCPUThrottlingRate',{rate:profile.cpu});if(profile.network)await cdp.send('Network.emulateNetworkConditions',profile.network);
   const errors=[],failedRequests=[],httpErrors=[],headers=[];
   page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>failedRequests.push({path:new URL(r.url()).pathname,error:r.failure()?.errorText}));
   page.on('response',r=>{if(r.status()>=400)httpErrors.push({path:new URL(r.url()).pathname,status:r.status()});if(pathname(r).startsWith('/app/')){const h=r.headers();headers.push({path:pathname(r),status:r.status(),cacheControl:h['cache-control']||null,contentEncoding:h['content-encoding']||null,contentLength:h['content-length']||null});}});
   await page.addInitScript(()=>{window.__longTasks=[];try{new PerformanceObserver(list=>{for(const e of list.getEntries())window.__longTasks.push({start:e.startTime,duration:e.duration});}).observe({type:'longtask',buffered:true});}catch{}});
   const runnerStart=clock.now();
   await page.goto(base+'/app/',{waitUntil:'load'});const authReadyMs=await authReady(page);const firstLoad=await navigationSnapshot(page);firstLoad.longTasks=await page.evaluate(()=>window.__longTasks);
   await page.reload({waitUntil:'load'});const reloadAuthReadyMs=await authReady(page);const reload=await navigationSnapshot(page);
   await page.locator('#email').fill(email);await page.locator('#password').fill(password);
   const pending=[page.waitForResponse(r=>r.request().method()==='POST'&&pathname(r)==='/login'),...['/shifts/current','/operations/summary','/ai/status'].map(path=>responseWait(page,path))];
   await startClick(page,'#login-button');const responses=await Promise.all(pending);await Promise.all(responses.map(r=>r.finished()));
   for(const r of responses)if(r.status()!==200)throw new Error(`Login/overview HTTP ${r.status()} at ${pathname(r)}`);
   await page.waitForFunction(()=>document.querySelectorAll('#overview-equipment .equipment-card').length===3&&!document.getElementById('overview-refresh').disabled&&document.getElementById('connection-status').dataset.state==='online');
   await frameSettled(page);const loginOverviewReadyMs=await clickElapsed(page);
   const navigation=[];
   for(const name of ['handover','history','new-record','overview'])navigation.push(await navigate(page,name));
   const oldTheme=await page.locator('html').getAttribute('data-theme');await startClick(page,'#dashboard [data-theme-toggle]');
   await page.waitForFunction(old=>document.documentElement.dataset.theme!==old,oldTheme);await frameSettled(page);const themeToggleMs=await clickElapsed(page);
   const longTasks=await page.evaluate(()=>window.__longTasks);
   const record={trial,authReadyMs,reloadAuthReadyMs,loginOverviewReadyMs,navigation,themeToggleMs,firstLoad,reload,assetHeaders:headers,longTasks,errors,failedRequests,httpErrors,runnerTotalMs:clock.now()-runnerStart};
   collected.trials.push(record);console.log(`${profile.name} trial ${trial}/${n}: auth ${authReadyMs.toFixed(0)} ms; login→overview ${loginOverviewReadyMs.toFixed(0)} ms`);
   await context.close();
  }
  collected.summary={authReadyMs:stats(collected.trials.map(t=>t.authReadyMs)),reloadAuthReadyMs:stats(collected.trials.map(t=>t.reloadAuthReadyMs)),loginOverviewReadyMs:stats(collected.trials.map(t=>t.loginOverviewReadyMs)),themeToggleMs:stats(collected.trials.map(t=>t.themeToggleMs)),navigation:Object.fromEntries(['handover','history','new-record','overview'].map(name=>[name,stats(collected.trials.map(t=>t.navigation.find(v=>v.page===name).durationMs))]))};
  result.profiles.push(collected);await writeFile(output+'/browser-results.json',JSON.stringify(result,null,2));
 }
}finally{await browser.close();}
await writeFile(output+'/browser-results.json',JSON.stringify(result,null,2));
console.log('Saved browser-results.json; inspect sample count and definitions before interpreting timings.');
