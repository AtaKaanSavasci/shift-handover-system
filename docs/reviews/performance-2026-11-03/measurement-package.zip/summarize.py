import json,statistics,gzip
from pathlib import Path
p=Path('/workspace/artifacts/performance-2026-11-03')
profiles={k:json.loads((p/f'api-{k}.json').read_text()) for k in ['1cpu','0.1cpu']}
runtime=[json.loads(l) for l in (p/'metrics/runtime.jsonl').read_text().splitlines() if l]
s={'sourceCommit':json.loads((p/'environment.json').read_text())['sourceCommit'],'reportDate':'2026-11-03','environment':json.loads((p/'environment.json').read_text()),'fixture':json.loads((p/'fixture-1cpu.json').read_text())['counts'],'profiles':{},'browser':json.loads((p/'browser-results.json').read_text()),'indexExperiment':json.loads((p/'index-experiment.json').read_text()),'payload':{}}
for ext in ['app.js','styles.css','index.html','theme.js','photo-upload.js']:
 b=(Path('/workspace/shift-handover-system/public')/ext).read_bytes();s['payload'][ext]={'rawBytes':len(b),'gzipBytes':len(gzip.compress(b,mtime=0))}
for name,x in profiles.items():
 rows=[]
 for c in x['cases']:
  q={k:v for k,v in c.items() if k not in ['samples','topSql']}
  q['topSql']=[{k:v for k,v in row.items()} for row in c['topSql'][:4]]
  metrics=[m for m in runtime if c['startAt']<=m['timestamp']<=c['endAt']]
  if metrics:q['runtime']={'sampleCount':len(metrics),'rssPeakMiB':max(m['rss'] for m in metrics)/1048576,'cpuMeanPercent':statistics.mean(m['cpuPercent'] for m in metrics),'cpuPeakPercent':max(m['cpuPercent'] for m in metrics),'eventLoopP95MaxMs':max(m['eventLoopP95ms'] for m in metrics)}
  rows.append(q)
 mix=[]
 for concurrency in sorted(set(c['concurrency'] for c in rows if c['name']=='handover-read-mix')):
  cases=[c for c in rows if c['name']=='handover-read-mix' and c['concurrency']==concurrency]
  mix.append({'concurrency':concurrency,'trials':len(cases),'requests':sum(c['completed'] for c in cases),'medianRps':statistics.median(c['rps'] for c in cases),'rpsMin':min(c['rps'] for c in cases),'rpsMax':max(c['rps'] for c in cases),'medianTrialP95ms':statistics.median(c['latencyMs']['p95'] for c in cases),'p95Min':min(c['latencyMs']['p95'] for c in cases),'p95Max':max(c['latencyMs']['p95'] for c in cases),'medianTrialP99ms':statistics.median(c['latencyMs']['p99'] for c in cases),'httpErrors':sum(sum(v for k,v in c['statuses'].items() if int(k)>=400) for c in cases),'transportErrors':sum(c['transportErrors'] for c in cases)})
 s['profiles'][name]={'cases':rows,'mix':mix,'reportedRequests':sum(c['completed'] for c in rows),'httpErrors':sum(sum(v for k,v in c['statuses'].items() if int(k)>=400) for c in rows),'transportErrors':sum(c['transportErrors'] for c in rows),'runtimeSampledPeakMiB':max(c.get('runtime',{}).get('rssPeakMiB',0) for c in rows),'timedSeconds':sum(c['seconds'] for c in rows)}
(p/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
for name,x in s['profiles'].items():
 print(name,'requests',x['reportedRequests'],'HTTP errors',x['httpErrors'],'transport',x['transportErrors'],'RSS peak',round(x['runtimeSampledPeakMiB'],1))
 print('paced',[(c['latencyMs'],c.get('runtime')) for c in x['cases'] if c['name']=='paced-10-sessions'])
 for c in x['mix']:print(c)
