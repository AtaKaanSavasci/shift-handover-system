# UI modernization preview and comparison harness

These scripts are local, synthetic test tools. They do not read `.env`, create
users, use a database, call paid AI or expose writable application routes.
They use installed dependencies from `/workspace/shift-handover-system`; set
`UI_REPO_ROOT` to select another checkout. The output folder is this script folder.

The compiled `dist/frontend-assets.js` must exist. Before changing CSS, freeze the
baseline production `public/` build at `baseline-public/`. Build the updated app
normally into the checkout's `public/`. Use the same dependencies and runtime for
both variants. Do not rebuild either directory during a measurement.

Start the two local previews:

```sh
node preview-servers.mjs
```

The same Node process serves the existing static delivery middleware at
127.0.0.1:3100 (baseline) and 127.0.0.1:3101 (updated). There is no real API.
Stop this owned process with Ctrl+C when finished. No Docker or package install
is needed. The Chromium path defaults to `/usr/bin/chromium`; override it with
`PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` when needed.

Capture the unchanged baseline first, then the updated build:

```sh
node compare-ui.mjs capture baseline --all-pages
node compare-ui.mjs capture updated --all-pages
```

To show fixed navigation in its actual visible viewport rather than in the middle
of a long full-page image, capture auth/overview viewport screenshots:

```sh
node compare-ui.mjs capture all --viewport-only
```

Viewport captures add `-viewport` to every image and metadata filename, preserving
the full-page captures. Combine `--viewport-only --all-pages` if all destinations
are needed at the same viewport dimensions.

Without `--all-pages`, capture only auth and overview. Captures cover desktop and
mobile in both themes. They use settled reduced-motion rendering and a synthetic
read-only fixture. Routing disables browser caching, so screenshots do not supply
startup/cache performance evidence. Each capture checks errors and page overflow.

After all source edits/builds/tests are finished, compare startup:

```sh
node compare-ui.mjs startup
```

This uses five fresh contexts per profile and variant in alternating order.
There are **no routes/mocks, cache disabling or service workers** in this mode.
Each context first loads the anonymous auth screen, visits about:blank, and
returns with the same cache. The harness asserts zero asset transfer on return.
Desktop is 1440×1000 without artificial throttling. Mobile is 390×844, fourfold
client CPU slowdown, 150 ms latency, 1.6 Mbps download and 750 Kbps upload.
Readiness means visible auth UI and enabled login button plus two animation frames.
`layoutShiftSum` is a local sum, not the field CLS session-window metric.

```sh
node compare-ui.mjs navigation
```

Navigation uses the synthetic fixture and measures browser click-event-to-ready
time for the four destinations, with five contexts/profile/variant. It isolates
client UI, not backend or real-network performance. It does not wait for the end
of a decorative transition because interactions stay available during it.

Avoid unrelated CPU-intensive work during measurements. These small local samples
are descriptive comparisons, not field Core Web Vitals or physical-phone results.
