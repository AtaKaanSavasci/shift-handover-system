const instant = '2026-11-08T08:20:00.000Z';
const person = { id: 1, name: 'Demo Operatör' };
const work = (id, kind, title, priority, equipmentCode, description, responsibleTeam, nextStep) => ({
  id, kind, title, priority, equipmentCode, description, responsibleTeam, nextStep,
  workStatus: kind === 'TASK' ? 'IN_PROGRESS' : 'WAITING', workVersion: 1,
  createdAt: instant, author: person, shiftId: 1, closedAt: null, photos: [], updates: [], _count: { updates: 0 }
});
const task = work(1, 'TASK', 'GT2 bakım kontrolü devam ediyor', 'NORMAL', 'GT2',
  'Bakım sonrası kontroller sürüyor. Sonuçlar doğrulanmadan iş kapatılmamalı.', 'Mekanik bakım', 'Kontrol sonucunu sonraki vardiyaya bildir.');
const attention = work(2, 'ATTENTION', 'GT1 titreşim değerleri takip edilecek', 'HIGH', 'GT1',
  'Son ölçümde titreşim artışı görüldü. Ölçümler izlenmeli ve bakım ekibi bilgilendirilmeli.', 'Operasyon', 'Yeni ölçümü kaydet ve önceki değerle karşılaştır.');
const valve = work(3, 'VALVE', 'ST drenaj vanası kontrol altında tutulacak', 'NORMAL', 'ST',
  'Vana konumu vardiya devrinde kontrol edilmeli. İş tamamlanana kadar kayıt açık kalacak.', 'Saha ekibi', 'Vana durumunu yerinde doğrula.');
const note = { ...work(4, 'NOTE', 'Vardiya gözlem notu', 'NORMAL', 'GT1',
  'Ünite değerleri izlendi. Bakım ekibiyle yapılan görüşme sonraki vardiyaya aktarıldı.', '', ''), workStatus: 'OPEN' };
const equipment = [
  { code: 'GT1', status: 'ACTIVE', note: 'Titreşim ölçümleri takip ediliyor.' },
  { code: 'GT2', status: 'MAINTENANCE', note: 'Planlı bakım ve kontroller sürüyor.' },
  { code: 'ST', status: 'ACTIVE', note: 'Drenaj vanası kontrol edilecek.' }
].map(item => ({ ...item, version: 1, updatedAt: instant, updatedBy: person }));
const shift = { id: 1, startTime: '2026-11-08T05:00:00.000Z', status: 'ACTIVE',
  shiftDate: '2026-11-08', scheduledStart: '08:00', scheduledEnd: '16:00', user: person };
const history = [
  { ...shift, id: 3, status: 'COMPLETED', startTime: '2026-11-07T13:00:00.000Z', endTime: '2026-11-07T21:00:00.000Z', shiftDate: '2026-11-07', scheduledStart: '16:00', scheduledEnd: '00:00' },
  { ...shift, id: 2, status: 'COMPLETED', startTime: '2026-11-06T05:00:00.000Z', endTime: '2026-11-06T13:00:00.000Z', shiftDate: '2026-11-06' }, shift
];
export const summary = {
  revision: 1, equipment, counts: { total: 3, important: 1, VALVE: 1, TASK: 1, ATTENTION: 1 },
  important: [attention], openItems: [attention, task, valve], tasks: [task], valves: [valve], attention: [attention], recent: [note],
  activeShiftId: 1, receipt: null,
  changes: { shiftDate: '2026-11-08', scheduledStart: '08:00', scheduledEnd: '16:00', since: '2026-11-08T05:00:00.000Z',
    counts: { NEW_ENTRY: 3, CLOSED_ENTRY: 1, PROGRESS: 2, EQUIPMENT: 1, WORK_DETAILS: 1 }, total: 8,
    items: [
      { type: 'EQUIPMENT', id: 10, entryId: null, title: 'GT2', body: 'Planlı bakım kontrolleri başladı.', equipmentCode: 'GT2', fromStatus: 'ACTIVE', toStatus: 'MAINTENANCE', actorName: person.name, createdAt: instant },
      { type: 'PROGRESS', id: 11, entryId: task.id, kind: task.kind, title: task.title, body: 'İlk kontrol tamamlandı, ölçüm sonucu bekleniyor.', equipmentCode: 'GT2', actorName: person.name, createdAt: instant },
      { type: 'NEW_ENTRY', id: attention.id, entryId: attention.id, kind: attention.kind, title: attention.title, body: attention.description, equipmentCode: 'GT1', actorName: person.name, createdAt: instant }
    ]
  }
};

export async function installFixture(page) {
  const json = (route, body, status = 200) => route.fulfill({ status, headers: { 'Cache-Control': 'no-store' }, json: body });
  await page.route('**/login', route => json(route, { token: 'synthetic-ui-preview-token', user: { ...person, role: 'WORKER', email: 'preview@example.invalid' } }));
  await page.route('**/ai/**', route => json(route, { enabled: false }));
  await page.route(/\/shifts(?:[/?]|$)/, route => {
    const url = new URL(route.request().url());
    if (url.pathname === '/shifts/current') return json(route, { currentShift: shift });
    if (url.pathname === '/shifts') return json(route, { items: history, total: history.length, page: 1, pageSize: 20 });
    return json(route, { error: 'Preview fixture is read-only.' }, 403);
  });
  await page.route('**/operations/**', route => {
    const request = route.request(), url = new URL(request.url());
    if (request.method() !== 'GET') return json(route, { error: 'Preview fixture is read-only.' }, 403);
    if (url.pathname === '/operations/summary') return json(route, summary);
    if (url.pathname === '/operations/equipment') return json(route, { items: equipment });
    if (url.pathname === '/operations/entries') {
      const items = url.searchParams.get('view') === 'history' ? [note] : [attention, task, valve];
      return json(route, { items, total: items.length, page: 1, pageSize: 20 });
    }
    const id = Number(url.pathname.split('/')[3]), entry = [task, attention, valve, note].find(item => item.id === id) || task;
    if (url.pathname.endsWith('/updates') || url.pathname.endsWith('/work')) return json(route, { entry, items: [], total: 0, page: 1, pageSize: 20, canWrite: true });
    return json(route, { error: 'Unknown preview fixture route.' }, 404);
  });
}

export async function loginFixture(page) {
  await page.locator('#email').fill('preview@example.invalid');
  await page.locator('#password').fill('synthetic-ui-preview-password');
  await page.locator('#login-button').click();
  await page.locator('#dashboard').waitFor({ state: 'visible' });
  await page.waitForFunction(() => document.querySelectorAll('#overview-important .observation-card').length === 3 && document.querySelectorAll('#overview-equipment .equipment-card').length === 3);
}
