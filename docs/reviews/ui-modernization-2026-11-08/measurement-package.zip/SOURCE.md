# Source versions

Baseline: 35961353759de7cbb746e89ddef8c13a43e9cc59.
Updated product source: frontend/styles.css in the commit containing this archive.
Dependencies/lockfile unchanged between variants.

The archive omits generated public builds. Rebuild the baseline in a separate
checkout with the lockfile, and copy its public output to baseline-public beside
the scripts. Build the updated checkout and set UI_REPO_ROOT to its absolute
path. The existing dist/frontend-assets.js must also be built. Follow
README-harness.md. Supply a synthetic DATABASE_URL for Prisma generation and
DOTENV_CONFIG_PATH=/dev/null to avoid reading local secrets. No database is
needed to serve or measure these static previews.

The comparison does not use the real authentication or operation API. All
fixture records, accounts and database credentials in test logs are synthetic.
