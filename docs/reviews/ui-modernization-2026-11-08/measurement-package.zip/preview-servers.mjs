import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve } from 'node:path';
import { access } from 'node:fs/promises';

const checkout = resolve(process.env.UI_REPO_ROOT || '/workspace/shift-handover-system');
const output = dirname(fileURLToPath(import.meta.url));
const require = createRequire(checkout + '/package.json');
const express = require('express'), helmet = require('helmet');
const { frontendAssets } = await import(pathToFileURL(checkout + '/dist/frontend-assets.js'));
const servers = [];
try {
  for (const [variant, directory, port] of [
    ['baseline', output + '/baseline-public', 3100],
    ['updated', checkout + '/public', 3101]
  ]) {
    await access(directory + '/index.html');
    const app = express();
    app.disable('x-powered-by');
    app.use(helmet({ contentSecurityPolicy: { directives: {
      imgSrc: ["'self'", 'data:', 'blob:'], upgradeInsecureRequests: null
    } } }));
    app.use((_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
    app.get('/', (_req, res) => res.redirect('/app/'));
    app.use('/app', frontendAssets(directory));
    // Preview-only: there is no database, real authentication or writable API.
    app.use((_req, res) => res.status(404).json({ error: 'Static UI comparison preview.' }));
    const server = app.listen(port, '127.0.0.1');
    await new Promise((yes, no) => { server.once('listening', yes); server.once('error', no); });
    servers.push(server);
    console.log(`${variant} preview ready: http://127.0.0.1:${port}/app/`);
  }
} catch (error) {
  for (const server of servers) server.close();
  throw error;
}
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  await Promise.all(servers.map(server => new Promise(resolve => {
    server.closeAllConnections(); server.close(resolve);
  })));
}
process.on('SIGTERM', stop); process.on('SIGINT', stop);
