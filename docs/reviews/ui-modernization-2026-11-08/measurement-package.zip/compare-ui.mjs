import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, relative } from 'node:path';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { installFixture, loginFixture } from './fixture.mjs';

const checkout = resolve(process.env.UI_REPO_ROOT || '/workspace/shift-handover-system');
const output = dirname(fileURLToPath(import.meta.url));
const require = createRequire(checkout + '/package.json'), { chromium } = require('@playwright/test');
const variants = [{ name: 'baseline', base: 'http://127.0.0.1:3100' }, { name: 'updated', base: 'http://127.0.0.1:3101' }];
const profiles = [
  { name: 'desktop', viewport: { width: 1440, height: 1000 }, isMobile: false, hasTouch: false, cpu: 1 },
  { name: 'mobile', viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, cpu: 4,
    network: { offline: false, latency: 150, downloadThroughput: 200000, uploadThroughput: 93750, connectionType: 'cellular4g' } }
];
const positional = process.argv.slice(2).filter(value => !value.startsWith('--'));
const mode = positional[0], chosen = positional[1] || 'all';
const viewportOnly = process.argv.includes('--viewport-only');
if (!['startup', 'capture', 'navigation'].includes(mode) || !['all', 'baseline', 'updated'].includes(chosen)) {
  console.error('Usage: node compare-ui.mjs startup|capture|navigation [baseline|updated|all] [--all-pages] [--viewport-only]');
  process.exit(2);
}
const selected = variants.filter(item => chosen === 'all' || item.name === chosen);
const frames = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
const median = values => { values = [...values].sort((a, b) => a - b); return values[Math.floor(values.length / 2)]; };
const statistics = values => ({ median: median(values), min: Math.min(...values), max: Math.max(...values) });
async function inventory(directory) {
  const result = [];
  async function walk(folder) {
    for (const entry of await fs.readdir(folder, { withFileTypes: true })) {
      const file = resolve(folder, entry.name);
      if (entry.isDirectory() && !entry.name.startsWith('.')) await walk(file);
      else if (entry.isFile() && /\.(?:html|css|js)$/.test(entry.name)) {
        const content = await fs.readFile(file), compressed = {};
        for (const extension of ['gz', 'br']) { try { compressed[extension] = (await fs.stat(file + '.' + extension)).size; } catch { compressed[extension] = null; } }
        result.push({ path: relative(directory, file), bytes: content.length, sha256: createHash('sha256').update(content).digest('hex'), ...compressed });
      }
    }
  }
  await walk(directory); return result.sort((a, b) => a.path.localeCompare(b.path));
}
async function ready(variant) {
  const response = await fetch(variant.base + '/app/');
  assert.equal(response.status, 200, variant.name + ' preview readiness'); await response.text();
}
async function contextFor(browser, profile, theme = 'light', reducedMotion = 'no-preference') {
  const { name, cpu, network, ...settings } = profile;
  const context = await browser.newContext({ ...settings, deviceScaleFactor: 1, locale: 'tr-TR', timezoneId: 'Europe/Istanbul', reducedMotion });
  await context.addInitScript(theme => { try { localStorage.setItem('vardiya-theme', theme); localStorage.setItem('vardiya-language', 'tr'); } catch {} }, theme);
  await context.addInitScript(() => {
    window.__uiLayoutShiftSum = 0;
    new PerformanceObserver(list => { for (const item of list.getEntries()) if (!item.hadRecentInput) window.__uiLayoutShiftSum += item.value; }).observe({ type: 'layout-shift', buffered: true });
  });
  const page = await context.newPage(), session = await context.newCDPSession(page);
  await session.send('Emulation.setCPUThrottlingRate', { rate: cpu });
  if (network) { await session.send('Network.enable'); await session.send('Network.emulateNetworkConditions', network); }
  return { context, page };
}
function diagnostics(page) {
  const errors = [], failed = [], external = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push({ url: request.url(), error: request.failure()?.errorText }));
  page.on('request', request => { if (/^https?:/.test(request.url()) && new URL(request.url()).hostname !== '127.0.0.1') external.push(request.url()); });
  return { errors, failed, external };
}
async function authMeasure(page, url) {
  const response = await page.goto(url, { waitUntil: 'load' }); assert.ok(response && [200, 304].includes(response.status()));
  await page.locator('#auth-view').waitFor({ state: 'visible' });
  await page.waitForFunction(() => { const button = document.querySelector('#login-button'); return button && !button.disabled; });
  await frames(page);
  return page.evaluate(() => {
    const navigation = performance.getEntriesByType('navigation')[0];
    const resources = performance.getEntriesByType('resource').filter(item => new URL(item.name).pathname.startsWith('/app/')).map(item => ({ path: new URL(item.name).pathname, transfer: item.transferSize, encoded: item.encodedBodySize, decoded: item.decodedBodySize }));
    return { readyMs: performance.now(), htmlTransfer: navigation.transferSize, totalTransfer: navigation.transferSize + resources.reduce((sum, item) => sum + item.transfer, 0), assetTransfer: resources.reduce((sum, item) => sum + item.transfer, 0), resources, layoutShiftSum: window.__uiLayoutShiftSum, horizontalOverflow: document.documentElement.scrollWidth > innerWidth };
  });
}
async function navigate(page, section) {
  await page.locator(`[data-nav="${section}"]`).click();
  await page.locator(`#page-${section}`).waitFor({ state: 'visible' });
  await frames(page);
}

for (const variant of selected) await ready(variant);
const browser = await chromium.launch({ headless: true, executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || '/usr/bin/chromium' });
try {
  if (mode === 'startup') {
    const result = { date: '2026-11-08', browser: browser.version(), trialsPerVariantProfile: 5,
      method: 'Five fresh contexts per variant/profile; alternating variant order; first anonymous auth view then about:blank and return with the same cache. No request routing, mocks, cache disabling or service worker. Readiness is visible auth UI and enabled login button plus two animation frames. LayoutShiftSum is a local sum, not field CLS. One local Node process serves both variants with the existing frontend-assets middleware.',
      profiles, inventories: { baseline: await inventory(output + '/baseline-public'), updated: await inventory(checkout + '/public') }, samples: [] };
    for (const profile of profiles) for (let trial = 1; trial <= 5; trial++) for (const variant of trial % 2 ? selected : [...selected].reverse()) {
      const { context, page } = await contextFor(browser, profile), issues = diagnostics(page);
      const headers = [];
      page.on('response', response => { if (new URL(response.url()).pathname.startsWith('/app/')) headers.push({ path: new URL(response.url()).pathname, status: response.status(), encoding: response.headers()['content-encoding'] || null, cache: response.headers()['cache-control'] || null }); });
      const first = await authMeasure(page, variant.base + '/app/');
      await page.goto('about:blank'); const revisit = await authMeasure(page, variant.base + '/app/');
      assert.equal(first.horizontalOverflow, false); assert.equal(revisit.horizontalOverflow, false);
      assert.ok(first.resources.length > 0); assert.equal(revisit.assetTransfer, 0, variant.name + ' repeat asset transfer');
      assert.deepEqual(issues, { errors: [], failed: [], external: [] });
      result.samples.push({ profile: profile.name, variant: variant.name, trial, first, revisit, headers, ...issues });
      await fs.writeFile(output + '/startup-comparison.json', JSON.stringify(result, null, 2));
      console.log(`${profile.name} ${trial} ${variant.name}: first ${first.readyMs.toFixed(1)} ms, revisit ${revisit.readyMs.toFixed(1)} ms; ${first.totalTransfer}/${revisit.totalTransfer} B`);
      await context.close();
    }
    const summary = {};
    for (const profile of profiles) for (const variant of selected) {
      const rows = result.samples.filter(row => row.profile === profile.name && row.variant === variant.name);
      summary[profile.name + '-' + variant.name] = Object.fromEntries(['first', 'revisit'].map(phase => [phase, {
        readyMs: statistics(rows.map(row => row[phase].readyMs)), transferBytes: statistics(rows.map(row => row[phase].totalTransfer)), assetBytes: statistics(rows.map(row => row[phase].assetTransfer)), layoutShiftSum: statistics(rows.map(row => row[phase].layoutShiftSum))
      }]));
    }
    await fs.writeFile(output + '/startup-summary.json', JSON.stringify(summary, null, 2) + '\n');
  }
  if (mode === 'capture') {
    const captures = [], extraPages = process.argv.includes('--all-pages') ? ['new-record', 'handover', 'history'] : [];
    const suffix = viewportOnly ? '-viewport' : '';
    await fs.mkdir(output + '/screenshots', { recursive: true });
    for (const variant of selected) for (const profile of profiles) for (const theme of ['light', 'dark']) {
      // Screenshots are settled and unthrottled; this mode does not measure speed.
      const { context, page } = await contextFor(browser, { ...profile, cpu: 1, network: null }, theme, 'reduce');
      const issues = diagnostics(page);
      await page.goto(variant.base + '/app/', { waitUntil: 'load' }); await page.locator('#auth-view').waitFor({ state: 'visible' }); await frames(page);
      const authFile = `${variant.name}-${profile.name}-${theme}-auth${suffix}.png`;
      await page.screenshot({ path: output + '/screenshots/' + authFile, fullPage: !viewportOnly });
      await installFixture(page); await loginFixture(page); await page.waitForLoadState('networkidle'); await frames(page);
      for (const section of ['overview', ...extraPages]) {
        if (section !== 'overview') await navigate(page, section);
        await page.mouse.move(0, 0);
        await page.waitForLoadState('networkidle'); await frames(page);
        const file = `${variant.name}-${profile.name}-${theme}-${section}${suffix}.png`;
        await page.screenshot({ path: output + '/screenshots/' + file, fullPage: !viewportOnly });
        const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
        assert.equal(overflow, false, file + ' page overflow');
        captures.push({ variant: variant.name, profile: profile.name, theme, section, file });
      }
      assert.deepEqual(issues, { errors: [], failed: [], external: [] });
      captures.push({ variant: variant.name, profile: profile.name, theme, section: 'auth', file: authFile });
      console.log('Captured', variant.name, profile.name, theme, 'auth/overview', extraPages.join('/'));
      await context.close();
    }
    await fs.writeFile(output + `/captures-${chosen}${suffix}.json`, JSON.stringify({ method: 'Synthetic read-only API fixture; routing disables HTTP cache; reduced motion and no CPU/network throttling for settled screenshots.', view: viewportOnly ? 'viewport-only' : 'full-page', captures }, null, 2) + '\n');
  }
  if (mode === 'navigation') {
    const result = { date: '2026-11-08', browser: browser.version(), profiles: profiles.map(profile => ({ ...profile, network: null })),
      method: 'Synthetic API responses isolate client UI and are not backend latency measurements. Routing disables HTTP cache equally. Network throttling is disabled; desktop CPU is unthrottled and mobile client CPU is throttled 4x. Five fresh contexts/profile/variant, alternating variant order; each navigates new-record/handover/history/overview. Browser readiness is click event until visible destination plus two animation frames, without waiting for decorative animation completion.', samples: [] };
    for (const profile of profiles) for (let trial = 1; trial <= 5; trial++) for (const variant of trial % 2 ? selected : [...selected].reverse()) {
      const { context, page } = await contextFor(browser, { ...profile, network: null }), issues = diagnostics(page);
      await installFixture(page); await page.goto(variant.base + '/app/'); await loginFixture(page); await frames(page);
      for (const section of ['new-record', 'handover', 'history', 'overview']) {
        await page.evaluate(section => document.querySelector(`[data-nav="${section}"]`).addEventListener('click', () => { window.__uiNavigationStart = performance.now(); }, { once: true }), section);
        const started = performance.now(); await navigate(page, section);
        const readyMs = await page.evaluate(() => performance.now() - window.__uiNavigationStart);
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
        result.samples.push({ variant: variant.name, profile: profile.name, trial, section, readyMs, driverRoundTripMs: performance.now() - started });
      }
      assert.deepEqual(issues, { errors: [], failed: [], external: [] });
      await fs.writeFile(output + '/navigation-comparison.json', JSON.stringify(result, null, 2)); await context.close();
    }
    const summary = {};
    for (const profile of profiles) for (const variant of selected) for (const section of ['new-record', 'handover', 'history', 'overview']) {
      const rows = result.samples.filter(row => row.profile === profile.name && row.variant === variant.name && row.section === section);
      summary[`${profile.name}-${variant.name}-${section}`] = statistics(rows.map(row => row.readyMs));
    }
    await fs.writeFile(output + '/navigation-summary.json', JSON.stringify(summary, null, 2) + '\n');
  }
} finally { await browser.close(); }
