import os, subprocess, json
from pathlib import Path
root=Path('/workspace/shift-handover-system')
out=Path('/workspace/artifacts/ui-modernization-2026-11-08/e2e-final');out.mkdir(exist_ok=True)
env=dict(os.environ,DOTENV_CONFIG_PATH='/dev/null',DATABASE_URL='postgresql://ci:ci@127.0.0.1:55437/shift_ui',TEST_DATABASE_URL='postgresql://ci:ci@127.0.0.1:55437/shift_ui',PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH='/usr/bin/chromium')
results=[]
for spec in sorted((root/'tests/e2e').glob('*.spec.ts')):
    name=spec.name.removesuffix('.spec.ts')
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(['npm','run','test:e2e','--',str(spec.relative_to(root)),'--config=.github/playwright.config.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append({'suite':name,'exitCode':result.returncode})
    (out/'statuses.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,'exit',result.returncode,flush=True)
raise SystemExit(int(any(item['exitCode'] for item in results)))
